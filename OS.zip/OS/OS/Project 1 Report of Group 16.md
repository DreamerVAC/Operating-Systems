<h1 style="font-family: 'Times New Roman', monospace;"> Project 1 Report of Group 16</h1>

| Name          | Student ID | Contributions                                                |
| ------------- | ---------- | ------------------------------------------------------------ |
| Haojie Wu     | 22336241   | Implemented TASK 1 Alarm Clock                               |
| Rongfeng Shi  | 22336204   | Implemented TASK 2 Priority Scheduler                        |
| Jiawei Luo    | 22336009   | Implemented TASK 3 MLFQ;                                     |
| Hongfeng Wang | 22336226   | Dealed with conflicts and modified codes; Wrote the lab report |

<h2 style="font-family: 'Times New Roman', monospace; color:brown"> Task 0 (individual) </h2>

<h3 style="font-family: 'Times New Roman', monospace;"> Task 0.1 </h3>

<h4 style="font-family: 'Times New Roman', monospace;color:gray"> Ex 0.1 </h4>

![image.png](/api/users/image?path=821657/images/1716540487610.png)

![image.png](/api/users/image?path=821657/images/1716540637776.png)

<h3 style="font-family: 'Times New Roman', monospace;"> Task 0.2 </h3>

<h4 style="font-family: 'Times New Roman', monospace;color:gray"> Ex 0.2 </h4>

<span style="font-family: 'Georgia';">The first intruction that gets executed is `ljmp   $0xf000,$0xe05b`, whose address is `0xffff0`. </span>

<h4 style="font-family: 'Times New Roman', monospace;color:gray"> Ex 0.3 </h4>

<span style="font-family: 'Georgia';">* The bootloader uses the BIOS interrupt `0x13` to read disk sectors.</span>

<span style="font-family: 'Georgia';">* The bootloader checks for a specific partition type through instruction `cmpb $0x20, %es:4(%si)`. It scans the partition table entries starting from offset `446` (through instruction `mov $446, %si`) in the MBR, checking each entry to see if it matches the required partition type. If a matching partition is found and it's bootable (marked by `0x80`), the bootloader proceeds to load the kernel from this partition. If the partition table entry doesn't have the MBR signature (`0xaa55`), which means that the disk doesn't contain a valid partition table, the bootloader will skip to the next disk.</span>

<span style="font-family: 'Georgia';">* If the bootloader couldn't find the Pintos kernel, the bootloader will print `Not Found` and then invokes BIOS interrupt `0x18`.</span>

<span style="font-family: 'Georgia';">* Control is transferred to the kernel after it is loaded into memory, by reading the kernel's start address from its ELF header, setting up a far jump to this address.</span>

<h4 style="font-family: 'Times New Roman', monospace;color:gray"> Ex 0.4 </h4>

<span style="font-family: 'Georgia';">* At the entry of `main()`, the value of the expression `init_page_dir[pd_no(ptov(0))]` in hexadecimal format is `0xb850e430`.</span>

<span style="font-family: 'Georgia';">* When `palloc_get_page()` is called for the first time, the call stack is as:</span>
![image.png](/api/users/image?path=821657/images/1716885827186.png)
<span style="font-family: 'Georgia';">The return value is `0xc0101000`. The value of the expression `init_page_dir[pd_no(ptov(0))]` is `0x0`.</span>

<span style="font-family: 'Georgia';">* When `palloc_get_page()` is called for the third time, the call stack is as:</span>
![image.png](/api/users/image?path=821657/images/1716889053891.png)
<span style="font-family: 'Georgia';">The return value is `0xc0103000`. The value of the expression `init_page_dir[pd_no(ptov(0))]` is `0x102027`.</span>

<h3 style="font-family: 'Times New Roman', monospace;"> Task 0.3 </h3>

<h4 style="font-family: 'Times New Roman', monospace;color:gray"> Ex 0.5 </h4>

```
static void run_kshell(void){
    char buffer[256];
    printf("KSHELL> ");
    int index = 0;
    memset(buffer,0,sizeof(buffer));
    while(true){
        char c = input_getc();
        if(c=='\b' || c=='\x7f'){
            if(index>0){
                index--;
                buffer[index]='\0';
                printf("\b \b");
            }
        }else if(c=='\n'||c=='\r'){
            printf("\n");
            buffer[index]='\0';
            if(strcmp(buffer,"exit")==0){
                printf("Kernel Shell Terminated...\n");
                break;
            }else if(buffer[0] == 'e' && buffer[1] == 'c' && buffer[2] == 'h' && buffer[3] == 'o' && buffer[4] == ' '){
                printf("%s\n",buffer+5);
            }else if(strcmp(buffer,"whoami")==0){
                printf("u22336226\n");
            }else{
                printf("invalid command\n");
            }
            printf("KSHELL> ");
            memset(buffer,0,sizeof(buffer));
            index=0;
        }
        else if(c >= ' ' && c <= '~'){
            if(index<(int)(sizeof(buffer)-1)){
                buffer[index++]=c;
                putchar(c);
            }
        }
    }
}
```

<h2 style="font-family: 'Times New Roman', monospace; color:brown"> Task 1 (By Haojie Wu & Hongfeng Wang) </h2>

<h3 style="font-family: 'Times New Roman', monospace; color:gray"> 1.1 Data Structures </h3>

<h4 style="font-family: 'Times New Roman', monospace; color:green"> A1.1</h4>

* In `<thread.h>`:

1. Add in `struct thread`:

```
//睡眠时间
int64_t ticks_blocked;
```

2. Add declaration of function `blocked_thread_check`:

```
//检查线程sleep时间
void blocked_thread_check(struct thread *t,void *aux UNUSED);
```

* In `<thread.c>`:

1. Add initialization of variable `ticks_blocked` in `thread_create`:

```
//初始化ticks_blocked
t->ticks_blocked = 0;
```

2. Add implementation of function `blocked_thread_check`:

```
void blocked_thread_check(strcut thread *t,void *aux UNUSED){
    //线程处于睡眠状态且睡眠时间大于0时
    if(t->status==THREAD_BLOCKED && t->ticks_blocked>0){
        t->ticks_blocked--;
        if(t->ticks_blocked==0){//睡醒了
            thread_unblock(t);
        }
    }
}
```

* In `<timer.c>`

1. Add detection function in function `thread_interrupt`

```
//对每个线程都检测睡眠时间
thread_foreach (blocked_thread_check, NULL);
```

2. Modify the aim function `timer_sleep`

```
void timer_sleep(int64_t ticks) {
    if(ticks <= 0){
        return;
    }
    //当前状态是否可中断
    ASSERT(intr_get_level() == INTR_ON);
    //intr_disable: 调用intr_get_level；将intr_level(当前状态)改为不可中断
    //intr_get_level：返回intr_level（当前状态）
    //res: old_level可中断，intr_level不可中断
    enum intr_level old_level = intr_disable ();
    // 令当前线程睡眠tick次
    struct thread *current_thread = thread_current ();
    current_thread->ticks_blocked = ticks;
    thread_block ();
    //使线程恢复可中断状态
    intr_set_level (old_level);
}
```

<h3 style="font-family: 'Times New Roman', monospace; color:gray"> 1.2 Algorithms </h3>

<h4 style="font-family: 'Times New Roman', monospace; color:green"> A1.2</h4>

1. Ensure current the aim sleep time `ticks` >0 and current thread is interruptable.
2. Set the status of current thread to un-interruptable.
3. Make current thread sleep `ticks` ticks
4. Wake up current thread.
5. Set the status of current thread to interruptable.

<h4 style="font-family: 'Times New Roman', monospace; color:green"> A1.3</h4>

1. A variable `ticks_blocked` is added into `struct thread` and initialized in function `thread_create` to record its sleep time.
2. Function `time_interrupt` is modifed to check the thread's sleep time through adding the function `thread_foreach`, which executes function `blocked_thread_check` on every thread.
3. Function `blocked_thread_check` decrement variable `ticks_blocked` by 1 each tick. If it reaches 0 (or the thread's status is unblocked), wake up the thread.

<h3 style="font-family: 'Times New Roman', monospace; color:gray"> 1.3 Synchronization </h3>

<h4 style="font-family: 'Times New Roman', monospace; color:green"> A1.4</h4>

Every thread will be checked each time a thread calls function `timer_sleep` through function `thread_foreach` executing function `blocked_thread_check` on every thread.

<h4 style="font-family: 'Times New Roman', monospace; color:green"> A1.5</h4>

Before key instructions are executed, the status of current thread is asserted to un-interruptable.

<h3 style="font-family: 'Times New Roman', monospace; color:gray"> 1.4 Rationale </h3>

<h4 style="font-family: 'Times New Roman', monospace; color:green"> A1.6</h4>

If we use semaphore rather than timer interruption, there will be less accuracy and expansibility since the sleep time `ticks` are given and fixed. Otherwise, timer interruption is more simple and clear (for us after consideration).
**<h2 style="font-family: 'Times New Roman', monospace; color:brown">** Task 2 (By Rongfeng Shi & Hongfeng Wang) </h2>

<h3 style="font-family: 'Times New Roman', monospace; color:gray"> 2.1 Data Structures </h3>

<h4 style="font-family: 'Times New Roman', monospace; color:green"> A2.1</h4>

* Add in `struct thread`:

```
//原优先级
int base_priority;   
//线程所持锁列表               
struct list locks;       
//线程所等待目标锁           
struct lock *lock_waiting;
```

* Add in `struct lock`:

```
//用于优先级捐赠的列表关联项
struct list_elem elem;      
//请求此锁的进程中的最高优先级
int max_priority;
```

* Add in function `init_thread`:

```
t->base_priority = priority;
list_init (&t->locks);
t->lock_waiting = NULL;
```

* Add after function `thread_unblock` in function `thread_create`：

```
//睡醒后重新排序
thread_yield();
```

* Add function `thread_cmp_priority`:

```
//线程所持锁队列排序函数
bool thread_cmp_priority (const struct list_elem *a, const struct list_elem *b, void *aux UNUSED){
  return list_entry(a, struct thread, elem)->priority > list_entry(b, struct thread, elem)->priority;
}
```

* Add function `lock_cmp_priority`:

```
//锁所对应的优先级比较函数
bool lock_cmp_priority (const struct list_elem *a, const struct list_elem *b, void *aux UNUSED){
  return list_entry (a, struct lock, elem)->max_priority > list_entry (b, struct lock, elem)->max_priority;
}
```

* Add function `cond_sema_cmp_priority`:

```
//等待信号量比较函数
bool cond_sema_cmp_priority (const struct list_elem *a, const struct list_elem *b, void *aux UNUSED){
  struct semaphore_elem *sa = list_entry (a, struct semaphore_elem, elem);
  struct semaphore_elem *sb = list_entry (b, struct semaphore_elem, elem);
  return list_entry(list_front(&sa->semaphore.waiters), struct thread, elem)->priority > list_entry(list_front(&sb->semaphore.waiters), struct thread, elem)->priority;
}
```

* Changes about priority queue:

1. In function `thread_unblock`:

```
list_insert_ordered (&ready_list, &t->elem, (list_less_func *) &thread_cmp_priority, NULL);
```

2. In function `init_thread`:

```
list_insert_ordered (&all_list, &t->allelem, (list_less_func *) &thread_cmp_priority, NULL);
```

3. In function `thread_yield`:

```
list_insert_ordered (&ready_list, &cur->elem, (list_less_func *) &thread_cmp_priority, NULL);
```

4. In the loop of function `cond_signal`:

```
list_sort (&cond->waiters, cond_sema_cmp_priority, NULL);
```

5. In function `sema_down`:

```
list_insert_ordered (&sema->waiters, &thread_current ()->elem, thread_cmp_priority, NULL);
```

6. In fucntion `sema_up`:

```
list_sort (&sema->waiters, thread_cmp_priority, NULL);
```

* Add function `thread_set_priority`:

```
//线程设置优先级
void thread_set_priority (int new_priority){
  //若优先级静态
  if (thread_mlfqs)
    return;

  enum intr_level old_level = intr_disable ();

  struct thread *current_thread = thread_current ();
  int old_priority = current_thread->priority;
  current_thread->base_priority = new_priority;
  //保证线程优先级为本身或被捐赠中的最大优先级并重排线程池
  if (list_empty (&current_thread->locks) || new_priority > old_priority)
  {
    current_thread->priority = new_priority;
    thread_yield ();
  }

  intr_set_level (old_level);
}
```

* Add function `thread_hold_the_lock`:

```
//使线程持有锁
void thread_hold_the_lock(struct lock *lock){
  enum intr_level old_level = intr_disable ();
  list_insert_ordered (&thread_current ()->locks, &lock->elem, lock_cmp_priority, NULL);

  if (lock->max_priority > thread_current ()->priority)
  {
    thread_current ()->priority = lock->max_priority;
    thread_yield ();
  }

  intr_set_level (old_level);
}
```

* Add function `thread_donate_priority`:

```
//线程捐赠优先级
void thread_donate_priority (struct thread *t){
  enum intr_level old_level = intr_disable ();
  thread_update_priority (t);

  if (t->status == THREAD_READY)
  {
    list_remove (&t->elem);
     list_insert_ordered (&ready_list, &t->elem, thread_cmp_priority, NULL);
  }
  intr_set_level (old_level);
}
```

* Modify function `lock_acquire`:

```
void lock_acquire (struct lock *lock){
  struct thread *current_thread = thread_current ();
  struct lock *l;
  enum intr_level old_level;

  ASSERT (lock != NULL);
  ASSERT (!intr_context ());
  ASSERT (!lock_held_by_current_thread (lock));

  if (lock->holder != NULL && !thread_mlfqs)
  {
    current_thread->lock_waiting = lock;
    l = lock;
    while (l && current_thread->priority > l->max_priority)
    {
      l->max_priority = current_thread->priority;
      thread_donate_priority (l->holder);
      l = l->holder->lock_waiting;
    }
  }

  sema_down (&lock->semaphore);

  old_level = intr_disable ();

  current_thread = thread_current ();
  if (!thread_mlfqs)
  {
    current_thread->lock_waiting = NULL;
    lock->max_priority = current_thread->priority;
    thread_hold_the_lock (lock);
  }
  lock->holder = current_thread;

  intr_set_level (old_level);
}
```

* Add function `thread_update_priority`:

```
//线程更新优先级
void thread_update_priority (struct thread *t){
  enum intr_level old_level = intr_disable ();
  int max_priority = t->base_priority;
  int lock_priority;

  if (!list_empty (&t->locks))
  {
    list_sort (&t->locks, lock_cmp_priority, NULL);
    lock_priority = list_entry (list_front (&t->locks), struct lock, elem)->max_priority;
    if (lock_priority > max_priority)
      max_priority = lock_priority;
  }

  t->priority = max_priority;
  intr_set_level (old_level);
}
```

* Add function `thread_remove_lock`:

```
//线程移除锁
void thread_remove_lock (struct lock *lock){
  enum intr_level old_level = intr_disable ();
  list_remove (&lock->elem);
  thread_update_priority (thread_current ());
  intr_set_level (old_level);
}
```

* Add in function `lock_release`:

```
//若优先级静态
if (!thread_mlfqs)
     thread_remove_lock (lock);
```

<h4 style="font-family: 'Times New Roman', monospace; color:green"> A2.2</h4>

When a thread tries to acquire a lock and succeeds to acquire it as there are no other threads holding it yet, this lock gets added to the list of locks acquired by this thread `struct list locks`, if it fails to acquire the thread it waits on a semaphore, and its priority is donated to the thread currently holding the lock if it has a smaller priority, the lock `priority` member is also updated as to correspond to the highest priority of threads trying to acquire the lock, this means that a thread holding multiple locks should have a priority that corresponds to the maximum priority of locks it holds. Donation is aggregated to handle nested donations: the thread waiting on a lock donates to the thread holding the lock, the latter thread in turn donates to the thread holding the lock it waits on and so on...

```
Thread 1
 |
 | (Acquire Lock A)
 v
+------------+
| Lock A     |
| Priority X |
+------------+
 |
 | (Acquire Lock B)
 v
Thread 2 ----> Semaphore (waiting)
 |
 | (Priority Donation: P2 > X)
 v
+------------+
| Lock B     |
| Priority P2|
+------------+
 |
 | (Acquire Lock C)
 v
Thread 3 ----> Semaphore (waiting)
 |
 | (Priority Donation: P3 > P2)
 v
+------------+
| Lock C     |
| Priority P3|
+------------+
 |
 | (Acquire Lock D)
 v
Thread 4 ----> Semaphore (waiting)
 |
 | (Priority Donation: P4 > P3)
 v
+------------+
| Lock D     |
| Priority P4|
+------------+
 |
 | (Acquire Lock E)
 v
Thread 5 ----> Semaphore (waiting)
 |
 | (Priority Donation: P5 > P4)
 v
+------------+
| Lock E     |
| Priority P5|
+------------+

Priority Propagation:
Thread 5 (P5) -> Thread 4 (P5) -> Thread 3 (P5) -> Thread 2 (P5) -> Thread 1 (P5)
```

<h3 style="font-family: 'Times New Roman', monospace; color:gray"> 2.2 Algorithms </h3>

<h4 style="font-family: 'Times New Roman', monospace; color:green"> A2.3</h4>

Every list storing threads waiting on each lock, semaphore or condition variable is ordered by priority of threads in a descending order, when one of the synchronization primitives signals, it pops the thread with the highest priority from the front. A utility function `list_modify_ordered` for lists was added in *list.h* to keep the invariant whenever a thread's priority changes. This function rearranges thread's `list_elem` to keep the list invariant in O(n), instead of sorting each time which would take O(n logn).

<h4 style="font-family: 'Times New Roman', monospace; color:green"> A2.4</h4>

Thread A (P=33) tries to acquire a lock that thread B (P=32) holds; thread A's priority > thread B's priority, thus it calls `donate ()` and donates its priority to thread B. which sets priority to thread B, donation is iteratively aggregated to handle nested donations; thread B waits on some lock and donates its new priority to the lock holder and so on. After completion of priority donations, thread A sets itself to be waiting on the lock, and downs the semaphore causing itself to block until lock is released by holder with it being the thread waiting on the semaphore with the highest priority (first in waiters list). After getting unblocked, A adds the lock to its own list of acquired locks and sets `lock_waiting` to `NULL` and sets itself as holder of this lock.

<h4 style="font-family: 'Times New Roman', monospace; color:green"> A2.5</h4>

Thread A releases lock which thread B waits on: thread A sets `lock_holder` to NULL, and removes it from list of locks acquired by thread A, setting `lock_priority` to the highest priority of threads waiting on the lock (assuming it's thread B). Thread A 'ups' the lock's *semaphore* resulting in unblocking thread B and adding it to threads ready queue, but since thread A still has a greater priority or equal to thread B, thread B cannot preempt thread A, resulting in thread A resuming `lock_release ()`, noticing that thread A has not given away its donation yet, thread A donates itself its next priority to have, which is the priority of the highest priority of locks acquired by A, or A's original (default) priority.

<h3 style="font-family: 'Times New Roman', monospace; color:gray"> 2.3 Synchronization </h3>

<h4 style="font-family: 'Times New Roman', monospace; color:green"> A2.6</h4>

A race condition could occur if one thread A is interrupted by another thread B setting thread A's priority (by donation for instance) while thread A itself is trying to set its priority calling `thread_set_priority ()`. For example, if thread B has just set thread A's priority but thread A tries to reset its own priority before thread B is done, the ready list will possibly end up being messed up because the list will be sorted with an unexpected value for the priority of B. The easy way to avoid this would be to disable interrupts before calling `thread_set_priority ()` and re-enable them afterwards.
We can use a lock to avoid this race by forcing threads to acquire a lock to the thread priority before setting it and only relinquishing it after all of the priority setting is complete, but it would be of a greater overhead than merely disabling interrupts as `lock_acquire ()` itself must disable interrupts for sometime to perform priority donations, so it seemed to be intuitive to disable interrupts while setting priority.

<h3 style="font-family: 'Times New Roman', monospace; color:gray"> 2.4 Rationale </h3>

<h4 style="font-family: 'Times New Roman', monospace; color:green"> A2.7</h4>

Implementation does not limit nesting depth of priority donation to any amount, without the use of of a list of all donating threads for every thread. As usage of a list containing locks acquired by thread with setting lock's `priority` member to correspond to the thread with the highest priority waiting seemed to do the trick.

<h2 style="font-family: 'Times New Roman', monospace; color:brown"> Task 3 (By Jiawei Luo) </h2>

<h3 style="font-family: 'Times New Roman', monospace; color:gray"> 3.1 Data Structures </h3>

<h4 style="font-family: 'Times New Roman', monospace; color:green"> A3.1</h4>

* Modify file `fixed_point.h`

```
#ifndef __THREAD_FIXED_POINT_H
#define __THREAD_FIXED_POINT_H

/* Basic definitions of fixed point. */
typedef int fixed_t;
/* 16 LSB used for fractional part. */
#define FP_SHIFT_AMOUNT 16
/* Convert a value to fixed-point value. */
#define FP_CONST(A) ((fixed_t)(A << FP_SHIFT_AMOUNT))
/* Add two fixed-point value. */
#define FP_ADD(A,B) (A + B)
/* Add a fixed-point value A and an int value B. */
#define FP_ADD_MIX(A,B) (A + (B << FP_SHIFT_AMOUNT))
/* Substract two fixed-point value. */
#define FP_SUB(A,B) (A - B)
/* Substract an int value B from a fixed-point value A */
#define FP_SUB_MIX(A,B) (A - (B << FP_SHIFT_AMOUNT))
/* Multiply a fixed-point value A by an int value B. */
#define FP_MULT_MIX(A,B) (A * B)
/* Divide a fixed-point value A by an int value B. */
#define FP_DIV_MIX(A,B) (A / B)
/* Multiply two fixed-point value. */
#define FP_MULT(A,B) ((fixed_t)(((int64_t) A) * B >> FP_SHIFT_AMOUNT))
/* Divide two fixed-point value. */
#define FP_DIV(A,B) ((fixed_t)((((int64_t) A) << FP_SHIFT_AMOUNT) / B))
/* Get integer part of a fixed-point value. */
#define FP_INT_PART(A) (A >> FP_SHIFT_AMOUNT)
/* Get rounded integer of a fixed-point value. */
#define FP_ROUND(A) (A >= 0 ? ((A + (1 << (FP_SHIFT_AMOUNT - 1))) >> FP_SHIFT_AMOUNT) \
        : ((A - (1 << (FP_SHIFT_AMOUNT - 1))) >> FP_SHIFT_AMOUNT))

#endif /* thread/fixed_point.h */
```

* In file `timer.c`

1. Add in function `timer_interrupt`:

```
if (thread_mlfqs){
        thread_mlfqs_increase_recent_cpu_by_one ();
        if (ticks % TIMER_FREQ == 0)
            thread_mlfqs_update_load_avg_and_recent_cpu ();
        else if (ticks % 4 == 0)
            thread_mlfqs_update_priority (thread_current ());
}
```

* In file `thread.c`:

1. Add in `struct thread`:

```
//优先级
int nice;                           
//现在的cpu
fixed_t recent_cpu;
```

2. Add in function `init_thread`:

```
t->nice=0;
t->recent_CPU=FP_CONST(0);
```

3. Add a global variable `load_avg`

```
fixed_t load_avg;
```

4. Add in function `thread_start`:

```
load_avg = FP_const(0);
```

5. Modify function `thread_mlfqs_increase_recent_cpu_by_one`:

```
/* Increase recent_cpu by 1. */
void thread_mlfqs_increase_recent_cpu_by_one (void){
  ASSERT (thread_mlfqs);
  ASSERT (intr_context ());

  struct thread *current_thread = thread_current ();
  if (current_thread == idle_thread)
    return;
  current_thread->recent_cpu = FP_ADD_MIX (current_thread->recent_cpu, 1);
}
```

6. Modify function `thread_mlfqs_update_load_avg_and_recent_cpu`:

```
/* Every per second to refresh load_avg and recent_cpu of all threads. */
void thread_mlfqs_update_load_avg_and_recent_cpu (void){
  ASSERT (thread_mlfqs);
  ASSERT (intr_context ());

  size_t ready_threads = list_size (&ready_list);
  if (thread_current () != idle_thread)
    ready_threads++;
  load_avg = FP_ADD (FP_DIV_MIX (FP_MULT_MIX (load_avg, 59), 60), FP_DIV_MIX (FP_CONST (ready_threads), 60));

  struct thread *t;
  struct list_elem *e = list_begin (&all_list);
  for (; e != list_end (&all_list); e = list_next (e))
  {
    t = list_entry(e, struct thread, allelem);
    if (t != idle_thread)
    {
      t->recent_cpu = FP_ADD_MIX (FP_MULT (FP_DIV (FP_MULT_MIX (load_avg, 2), FP_ADD_MIX (FP_MULT_MIX (load_avg, 2), 1)), t->recent_cpu), t->nice);
      thread_mlfqs_update_priority (t);
    }
  }
}
```

7. Modify function `thread_mlfps_update_priority`

```
/* Update priority. */
void thread_mlfqs_update_priority (struct thread *t){
  if (t == idle_thread)
    return;

  ASSERT (thread_mlfqs);
  ASSERT (t != idle_thread);

  t->priority = FP_INT_PART (FP_SUB_MIX (FP_SUB (FP_CONST (PRI_MAX), FP_DIV_MIX (t->recent_cpu, 4)), 2 * t->nice));
  t->priority = t->priority < PRI_MIN ? PRI_MIN : t->priority;
  t->priority = t->priority > PRI_MAX ? PRI_MAX : t->priority;
}
```

8. Modify function `thread_set_nice`:

```
/* Sets the current thread's nice value to NICE. */
void thread_set_nice (int nice){
  thread_current ()->nice = nice;
  thread_mlfqs_update_priority (thread_current ());
  thread_yield ();
}
```

9. Modify function `thread_get_nice`:

```
/* Returns the current thread's nice value. */
int thread_get_nice (void){
  return thread_current ()->nice;
}
```

10. Modify function `thread_get_load_avg`:

```
/* Returns 100 times the system load average. */
int thread_get_load_avg (void){
  return FP_ROUND (FP_MULT_MIX (load_avg, 100));
}
```

11. Modify function `thread_get_recent_cpu`:

```
/* Returns 100 times the current thread's recent_cpu value. */
int thread_get_recent_cpu (void){
  return FP_ROUND (FP_MULT_MIX (thread_current ()->recent_cpu, 100));
}
```

<h3 style="font-family: 'Times New Roman', monospace; color:gray"> 3.2 Algorithms </h3>

<h4 style="font-family: 'Times New Roman', monospace; color:green"> A3.2</h4>

| Timer ticks | recent\_cpu (A B C) | priority (A B C) | Thread to run |
| ----------- | :-----------------: | :--------------: | ------------- |
| 0           |        0 0 0        |     63 61 59     | A             |
| 4           |        4 0 0        |     62 61 59     | A             |
| 8           |        8 0 0        |     61 61 59     | B             |
| 12          |        8 4 0        |     61 60 59     | A             |
| 16          |       12 4 0        |     60 60 59     | B             |
| 20          |       12 8 0        |     60 59 59     | A             |
| 24          |       16 8 0        |     59 59 59     | C             |
| 28          |       16 8 4        |     59 59 58     | B             |
| 32          |       16 12 4       |     59 58 58     | A             |
| 36          |       20 12 4       |     58 58 58     | C             |

<h4 style="font-family: 'Times New Roman', monospace; color:green"> A3.3</h4>

If the running thread has the same priority as some thread in the ready queue, the scheduler will take the one in the ready queue and then in the next time slice will do the same as round-robin. Yes this match with the scheduler as the highest priority one still the one in the running state but this is done to deliver more responsive system.

<h4 style="font-family: 'Times New Roman', monospace; color:green"> A3.4</h4>

Most of the calculations for `recent_cpu` and `priority` are done within timer interrupt every fixed number of ticks. Redundancy of calculations in `thread_tick ()` was managed to be cut down by updating priority only for the currently running thread every 4 ticks, and for all threads every 1 sec.

<h3 style="font-family: 'Times New Roman', monospace; color:gray"> 3.3 Rationale </h3>

<h4 style="font-family: 'Times New Roman', monospace; color:green"> A3.5</h4>

Implementation has some advantages in context of design simplicity, as it offers a relatively small thread struct size, the added functionality for `list.h`, specifically `list_modify_ordered ()` managed to cut down the need to perform O(n log n) sortings on ready queue every time a new thread is scheduled, redundancies in calculations were avoided as much as possible by updating priority only for the currently running thread every 4 ticks.

As for disadvantages, usage of linked lists greatly affected performance, as ordered insertions and modifications running in O(n) complexity are frequently used in code, one suggestion includes usage of a priority queue (Min/Max heaps per se) that supports insertion and modification in O(log n) time with some workaround to ensure stability, and eliminating the need to sort completely. Finally, considerations to refine the design may include detection of overflow in fixed-point operations.

<h4 style="font-family: 'Times New Roman', monospace; color:green"> A3.6</h4>

'fixed-point.h' was implemented completely by using macros that support fixed-point arithmetic operations, as they are usually faster as they do not need a function call or an activation record, also it allows the compiler to optimize the equations. Real numbers throughout implementation of the scheduler like those used in `recent_cpu` and `load_avg` were 'simulated' using fixed-point representation rather than floating-point arithemtic representation which is marginally slower, besides that it is not implemented in the kernel.